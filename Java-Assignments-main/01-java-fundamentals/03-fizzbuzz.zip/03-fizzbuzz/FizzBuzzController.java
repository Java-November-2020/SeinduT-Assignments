public class FizzBuzzController {
    public static void main(String[] args) {
        FizzBuzz fb = new FizzBuzz();

        fb.FizzBuzzTest();
    }
}