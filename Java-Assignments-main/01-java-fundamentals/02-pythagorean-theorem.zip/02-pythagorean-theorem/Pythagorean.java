public class Pythagorean {
    public double calculateHypothenuse (int lenA, int lenB) {
        return Math.sqrt((lenA * lenA) + (lenB * lenB));
    }
}