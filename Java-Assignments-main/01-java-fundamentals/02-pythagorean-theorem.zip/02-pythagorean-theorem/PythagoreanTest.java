public class PythagoreanTest {
    public static void main(String[] args) {
        Pythagorean py = new Pythagorean();
        double hypothenuse = py.calculateHypothenuse(8,12);
        System.out.println("The Hypothenuse is: " + hypothenuse);
    }
}