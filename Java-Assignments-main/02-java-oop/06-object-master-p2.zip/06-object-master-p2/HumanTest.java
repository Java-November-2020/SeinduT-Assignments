public class HumanTest {
    public static void main(String[] args) {
        Human h = new Human();
        
        h.setStrength(5);
        h.attack(h);
    }
}